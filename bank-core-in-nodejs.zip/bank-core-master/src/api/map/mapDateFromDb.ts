export const mapDateFromDb = (value: Date): string => {
    return value.toString();
};
