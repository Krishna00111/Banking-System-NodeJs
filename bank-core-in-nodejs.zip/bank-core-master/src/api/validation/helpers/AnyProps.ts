export type AnyProps<T> = { [key in keyof T]: any };
