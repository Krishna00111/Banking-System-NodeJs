export const appconfig = {
    port: process.env.PORT || 5000,
};
