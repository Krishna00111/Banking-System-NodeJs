export type CurrencyCodeDb = "usd" | "cny" | "pln";

export const currencyCodesDb = ["usd", "cny", "pln"];
