import moduleAlias from "module-alias";
moduleAlias.addAlias("@", __dirname);
